-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: openhab
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item62`
--

DROP TABLE IF EXISTS `item62`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item62` (
  `Time` datetime NOT NULL,
  `Value` varchar(20000) DEFAULT NULL,
  PRIMARY KEY (`Time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item62`
--

LOCK TABLES `item62` WRITE;
/*!40000 ALTER TABLE `item62` DISABLE KEYS */;
INSERT INTO `item62` VALUES ('2017-01-30 08:24:19','partly-cloudy-day'),('2017-01-30 09:24:19','cloudy'),('2017-01-30 10:24:19','cloudy'),('2017-01-30 11:24:19','cloudy'),('2017-01-30 12:24:19','few-showers'),('2017-01-30 13:24:19','cloudy'),('2017-01-30 14:24:19','few-showers'),('2017-01-30 15:24:22','few-showers'),('2017-01-30 16:24:19','few-showers'),('2017-01-31 08:51:29','fog'),('2017-01-31 09:51:29','few-showers'),('2017-01-31 10:51:29','few-showers'),('2017-01-31 11:51:29','few-showers'),('2017-01-31 12:51:29','fog'),('2017-01-31 13:51:29','few-showers'),('2017-01-31 14:51:30','few-showers'),('2017-01-31 15:51:29','fog'),('2017-01-31 16:51:29','cloudy'),('2017-02-01 08:51:29','fog'),('2017-02-01 09:51:29','fog'),('2017-02-01 10:51:29','fog'),('2017-02-01 11:51:29','partly-cloudy-day'),('2017-02-01 12:51:29','partly-cloudy-day'),('2017-02-01 13:51:29','mostly-cloudy-day'),('2017-02-01 14:51:30','mostly-cloudy-day'),('2017-02-01 15:51:30','mostly-cloudy-day'),('2017-02-01 16:51:30','mostly-cloudy-day'),('2017-02-02 08:51:29','fog'),('2017-02-02 09:51:29','fog'),('2017-02-02 10:51:29','fog'),('2017-02-02 11:51:29','sunny'),('2017-02-02 12:51:29','mostly-cloudy-day'),('2017-02-02 13:51:29','cloudy'),('2017-02-02 14:51:29','mostly-cloudy-day'),('2017-02-02 15:51:29','cloudy'),('2017-02-02 16:51:29','cloudy'),('2017-02-03 08:51:29','sunny'),('2017-02-03 09:51:29','sunny'),('2017-02-03 10:51:29','sunny'),('2017-02-03 11:51:30','mostly-cloudy-day'),('2017-02-03 12:51:29','sunny'),('2017-02-03 13:51:29','sunny'),('2017-02-03 14:51:30','few-showers'),('2017-02-03 15:51:30','few-showers'),('2017-02-06 08:51:29','few-showers'),('2017-02-06 09:51:29','few-showers'),('2017-02-06 10:51:29','few-showers'),('2017-02-06 11:51:29','cloudy'),('2017-02-06 12:51:29','cloudy'),('2017-02-06 13:51:29','cloudy'),('2017-02-06 14:51:29','cloudy'),('2017-02-06 15:51:29','cloudy'),('2017-02-07 08:51:29','cloudy'),('2017-02-07 09:51:29','few-showers'),('2017-02-07 10:51:29','few-showers'),('2017-02-07 11:51:29','few-showers'),('2017-02-07 12:51:29','few-showers'),('2017-02-07 13:51:32','few-showers'),('2017-02-07 14:51:30','few-showers'),('2017-02-07 15:51:30','fog'),('2017-02-07 16:51:29','fog'),('2017-02-08 08:51:29','fog'),('2017-02-08 09:51:29','fog'),('2017-02-08 10:51:29','fog'),('2017-02-08 11:51:30','few-showers'),('2017-02-08 12:51:29','few-showers'),('2017-02-08 13:51:30','few-showers'),('2017-02-08 14:51:30','few-showers'),('2017-02-08 15:51:29','few-showers'),('2017-02-08 16:51:30','few-showers'),('2017-02-09 08:51:29','cloudy'),('2017-02-09 09:51:29','cloudy'),('2017-02-09 10:51:29','cloudy'),('2017-02-09 11:51:29','fog'),('2017-02-09 12:51:29','fog'),('2017-02-09 13:51:30','cloudy'),('2017-02-09 14:51:29','cloudy'),('2017-02-09 15:51:29','cloudy'),('2017-02-09 16:51:29','fog'),('2017-02-10 08:51:29','few-showers'),('2017-02-10 09:51:29','fog'),('2017-02-10 10:51:29','fog'),('2017-02-10 11:51:29','partly-cloudy-day'),('2017-02-10 12:51:29','sunny'),('2017-02-10 13:51:29','mostly-cloudy-day'),('2017-02-10 14:51:29','mostly-cloudy-day'),('2017-02-10 15:51:29','mostly-cloudy-day'),('2017-02-13 08:51:29','sunny'),('2017-02-13 09:51:29','sunny'),('2017-02-13 10:51:29','sunny'),('2017-02-13 11:51:29','sunny'),('2017-02-13 12:51:29','sunny'),('2017-02-13 13:51:30','sunny'),('2017-02-13 14:51:29','sunny'),('2017-02-13 15:51:30','sunny'),('2017-02-14 08:51:29','mostly-cloudy-day'),('2017-02-14 09:51:29','mostly-cloudy-day'),('2017-02-14 10:51:29','mostly-cloudy-day'),('2017-02-14 11:51:29','cloudy'),('2017-02-14 12:51:29','cloudy'),('2017-02-14 13:51:29','cloudy'),('2017-02-14 14:51:29','cloudy'),('2017-02-14 15:51:29','mostly-cloudy-day'),('2017-02-14 16:51:29','mostly-cloudy-day'),('2017-02-15 08:51:29','mostly-cloudy-day'),('2017-02-15 09:51:29','mostly-cloudy-day'),('2017-02-15 10:51:29','mostly-cloudy-day'),('2017-02-15 11:51:29','few-showers'),('2017-02-15 12:51:29','few-showers'),('2017-02-15 13:51:29','few-showers'),('2017-02-15 14:51:29','few-showers'),('2017-02-15 15:51:29','few-showers'),('2017-02-15 16:51:30','mostly-cloudy-day'),('2017-02-16 08:51:29','sunny'),('2017-02-16 09:51:29','sunny'),('2017-02-16 10:51:29','sunny'),('2017-02-16 11:51:29','sunny'),('2017-02-16 12:51:29','sunny'),('2017-02-16 13:51:29','sunny'),('2017-02-16 14:51:29','partly-cloudy-day'),('2017-02-16 15:51:29','partly-cloudy-day'),('2017-02-16 16:51:29','partly-cloudy-day'),('2017-02-17 08:51:29','sunny'),('2017-02-17 09:51:29','sunny'),('2017-02-17 10:51:29','sunny'),('2017-02-17 11:51:29','sunny'),('2017-02-17 12:51:29','sunny'),('2017-02-17 13:51:29','sunny'),('2017-02-17 14:51:29','sunny'),('2017-02-17 15:51:29','sunny'),('2017-02-20 09:51:29','sunny'),('2017-02-20 10:51:29','sunny'),('2017-02-20 11:51:29','sunny'),('2017-02-20 12:51:29','sunny'),('2017-02-20 13:51:29','sunny'),('2017-02-20 14:51:29','sunny'),('2017-02-20 15:51:29','sunny'),('2017-02-20 16:51:31','sunny'),('2017-02-21 08:51:29','sunny'),('2017-02-21 09:51:29','sunny'),('2017-02-21 10:51:29','sunny'),('2017-02-21 11:51:29','sunny'),('2017-02-21 12:51:29','mostly-cloudy-day'),('2017-02-21 13:51:30','cloudy'),('2017-02-21 14:51:29','cloudy'),('2017-02-21 15:51:29','cloudy'),('2017-02-22 08:51:29','few-showers'),('2017-02-22 09:51:29','sunny'),('2017-02-22 10:51:29','sunny'),('2017-02-22 11:51:29','sunny'),('2017-02-22 12:51:29','partly-cloudy-day'),('2017-02-22 13:51:29','sunny'),('2017-02-22 14:51:29','sunny'),('2017-02-22 15:51:29','sunny'),('2017-02-22 16:51:29','sunny'),('2017-02-23 08:51:29','sunny'),('2017-02-23 09:51:29','sunny'),('2017-02-23 10:51:29','sunny'),('2017-02-23 11:51:29','sunny'),('2017-02-23 12:51:29','sunny'),('2017-02-23 13:51:29','sunny'),('2017-02-23 14:51:29','sunny'),('2017-02-23 15:51:29','sunny'),('2017-02-23 16:51:29','sunny'),('2017-02-24 08:51:29','cloudy'),('2017-02-24 09:51:29','mostly-cloudy-day'),('2017-02-24 10:51:29','cloudy'),('2017-02-24 11:51:29','mostly-cloudy-day'),('2017-02-24 12:51:29','mostly-cloudy-day'),('2017-02-24 13:51:29','mostly-cloudy-day'),('2017-02-24 14:51:29','cloudy'),('2017-02-24 15:51:29','cloudy');
/*!40000 ALTER TABLE `item62` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-18 16:38:23
