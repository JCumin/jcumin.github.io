-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: openhab
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `ItemId` int(11) NOT NULL AUTO_INCREMENT,
  `ItemName` varchar(200) NOT NULL,
  PRIMARY KEY (`ItemId`)
) ENGINE=InnoDB AUTO_INCREMENT=401 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (22,'bathroom_shower_coldwater_instantaneous'),(23,'kitchen_washingmachine_partial_energy'),(24,'kitchen_sink_coldwater_total'),(25,'global_waterheater_voltage'),(26,'global_waterheater_partial_energy'),(27,'kitchen_oven_voltage'),(28,'livingroom_presence_table'),(29,'bathroom_sink_coldwater_total'),(31,'bathroom_heater_effective_setpoint'),(32,'bathroom_shower_coldwater_total'),(33,'global_shutters_voltage'),(35,'bedroom_AC_setpoint'),(36,'kitchen_cooktop_current'),(37,'global_waterheater_status'),(38,'kitchen_oven_power'),(40,'entrance_heater_base_setpoint'),(41,'kitchen_dishwasher_voltage'),(43,'livingroom_heater1_base_setpoint'),(45,'livingroom_presence_couch'),(46,'livingroom_heater1_effective_mode'),(47,'bathroom_CO2'),(48,'kitchen_hood_partial_energy'),(49,'bathroom_presence'),(51,'global_pressure_trend_ext'),(52,'global_condition_id_ext'),(53,'global_temperature_feel_ext'),(54,'global_humidity_ext'),(55,'global_wind_speed_ext'),(57,'global_condition_ext'),(58,'global_pressure_ext'),(59,'global_rain_ext'),(60,'global_temperature_ext'),(61,'global_wind_direction_ext'),(62,'global_commonID_ext'),(63,'global_snow_ext'),(64,'global_clouds_ext'),(68,'office_luminosity'),(69,'global_shutters_current'),(71,'global_coldwater_instantaneous'),(72,'livingroom_heater2_effective_mode'),(73,'kitchen_fridge_power'),(75,'kitchen_sink_hotwater_total'),(76,'livingroom_heater2_temperature'),(77,'bathroom_heater_effective_mode'),(79,'global_current'),(80,'global_power_factor'),(81,'global_voltage'),(82,'global_active_power'),(83,'global_gas_total'),(84,'global_active_energy'),(85,'global_frequency'),(86,'bathroom_sink_coldwater_instantaneous'),(87,'bathroom_heater_temperature'),(89,'bedroom_heater2_effective_setpoint'),(91,'bedroom_heater1_temperature'),(92,'entrance_heater_temperature'),(94,'office_presence'),(96,'global_waterheater_total_energy'),(109,'entrance_heater_effective_setpoint'),(111,'livingroom_heater2_base_setpoint'),(113,'livingroom_couch_plug_consumption'),(115,'livingroom_table_luminosity'),(117,'livingroom_tv_plug_consumption'),(118,'livingroom_heater1_effective_setpoint'),(119,'office_desk_plug_consumption'),(120,'bedroom_luminosity'),(122,'kitchen_cooktop_total_energy'),(124,'entrance_heater_effective_mode'),(126,'global_shutters_total_energy'),(127,'livingroom_table_plug_consumption'),(128,'bedroom_CO2'),(130,'bathroom_temperature'),(131,'bedroom_heater1_effective_mode'),(132,'office_tv_plug_consumption'),(133,'livingroom_temperature'),(135,'bathroom_sink_hotwater_total'),(136,'kitchen_humidity'),(161,'kitchen_luminosity'),(162,'bedroom_heater1_effective_setpoint'),(164,'global_shutters_partial_energy'),(165,'kitchen_hood_voltage'),(166,'global_shutters_power'),(167,'kitchen_dishwasher_current'),(168,'livingroom_AC_setpoint'),(169,'kitchen_oven_total_energy'),(170,'kitchen_hood_current'),(171,'bedroom_heater2_effective_mode'),(173,'kitchen_washingmachine_total_energy'),(174,'bathroom_heater_base_setpoint'),(175,'kitchen_cooktop_voltage'),(177,'office_heater_effective_mode'),(178,'global_waterheater_power'),(179,'livingroom_luminosity'),(180,'office_AC_setpoint'),(182,'office_heater_effective_setpoint'),(183,'kitchen_fridge_partial_energy'),(184,'kitchen_sink_hotwater_instantaneous'),(185,'livingroom_heater2_effective_setpoint'),(187,'global_lighting_voltage'),(188,'kitchen_hood_power'),(189,'kitchen_sink_coldwater_instantaneous'),(190,'bathroom_luminosity'),(191,'bedroom_temperature'),(193,'kitchen_dishwasher_partial_energy'),(194,'kitchen_dishwasher_total_energy'),(195,'global_coldwater_total'),(197,'bedroom_humidity'),(198,'kitchen_dishwasher_power'),(200,'kitchen_washingmachine_power'),(201,'bathroom_shower_hotwater_instantaneous'),(204,'kitchen_fridge_total_energy'),(205,'global_waterheater_current'),(206,'bathroom_shower_hotwater_total'),(207,'bedroom_light1'),(208,'bedroom_light2'),(209,'bathroom_light1'),(210,'entrance_light1'),(212,'livingroom_light1'),(213,'staircase_light'),(214,'bedroom_light3'),(215,'toilet_light'),(216,'office_heater_base_setpoint'),(218,'livingroom_light2'),(220,'bedroom_light4'),(221,'walkway_light'),(222,'office_light'),(223,'kitchen_light1'),(226,'bathroom_light2'),(229,'kitchen_CO2'),(230,'kitchen_light2'),(232,'kitchen_oven_current'),(233,'bathroom_humidity'),(236,'global_lighting_total_energy'),(237,'kitchen_fridge_voltage'),(239,'office_heater_command'),(240,'global_heaters_setpoint'),(241,'kitchen_washingmachine_current'),(242,'bedroom_heater1_base_setpoint'),(243,'livingroom_heater1_temperature'),(244,'bedroom_heater2_base_setpoint'),(246,'bedroom_heater2_temperature'),(247,'office_heater_temperature'),(248,'kitchen_hood_total_energy'),(251,'toilet_coldwater_total'),(253,'livingroom_humidity'),(254,'toilet_coldwater_instantaneous'),(255,'kitchen_cooktop_partial_energy'),(256,'kitchen_washingmachine_voltage'),(257,'global_lighting_current'),(258,'bathroom_heater_command'),(262,'bedroom_presence'),(264,'bathroom_sink_hotwater_instantaneous'),(265,'kitchen_fridge_current'),(266,'global_lighting_partial_energy'),(268,'livingroom_CO2'),(269,'kitchen_presence'),(271,'global_lighting_power'),(272,'global_heaters_temperature'),(273,'office_AC_mode'),(274,'kitchen_temperature'),(275,'bedroom_heater1_command'),(276,'kitchen_cooktop_power'),(277,'kitchen_oven_partial_energy'),(278,'bedroom_heater2_command'),(279,'entrance_heater_command'),(280,'livingroom_heater2_command'),(281,'livingroom_heater1_command'),(282,'livingroom_tv_status'),(283,'office_tv_status'),(286,'livingroom_couch_noise'),(287,'office_noise'),(288,'bedroom_noise'),(289,'walkway_noise'),(290,'livingroom_table_noise'),(291,'livingroom_switch1_bottom_left'),(292,'livingroom_shutter2'),(293,'livingroom_shutter3'),(294,'livingroom_shutter4'),(295,'livingroom_shutter5'),(297,'livingroom_switch1_top_right'),(298,'livingroom_switch2_top_right'),(299,'livingroom_shutter1'),(300,'kitchen_cupboard1'),(301,'kitchen_noise'),(302,'kitchen_switch_bottom_right'),(303,'entrance_noise'),(304,'kitchen_switch_top_right'),(305,'entrance_door'),(306,'entrance_switch_left'),(307,'walkway_switch1_bottom_right'),(310,'bedroom_shutter1'),(311,'office_shutter'),(312,'bedroom_shutter2'),(314,'kitchen_fridge_door'),(315,'kitchen_cupboard2'),(316,'kitchen_cupboard3'),(317,'kitchen_cupboard4'),(318,'staircase_switch_left'),(319,'walkway_switch1_bottom_left'),(320,'walkway_switch1_top_left'),(322,'walkway_switch1_top_right'),(323,'walkway_switch2_top_left'),(324,'walkway_switch2_bottom_left'),(328,'walkway_switch2_bottom_right'),(329,'walkway_switch2_top_right'),(330,'bathroom_switch_top_left'),(331,'bathroom_switch_bottom_left'),(332,'bathroom_switch_bottom_right'),(333,'bathroom_switch_top_right'),(334,'bathroom_door'),(335,'bedroom_switch_top_left'),(336,'bedroom_switch_top_right'),(337,'bedroom_switch_bottom_left'),(338,'bedroom_switch_bottom_right'),(339,'bedroom_closet_door'),(340,'bedroom_door'),(341,'office_switch_left'),(342,'office_switch_right'),(343,'office_door'),(344,'staircase_switch_right'),(345,'kitchen_switch_top_left'),(346,'kitchen_switch_bottom_left'),(347,'toilet_switch_left'),(348,'toilet_switch_right'),(349,'bedroom_bed_pressure'),(351,'livingroom_switch2_top_left'),(352,'bathroom_shower_door'),(353,'livingroom_switch1_top_left'),(354,'office_switch_middle'),(355,'kitchen_cupboard5'),(356,'bedroom_switch_middle_left'),(357,'bedroom_drawer1'),(358,'bedroom_drawer2'),(360,'bedroom_switch_middle_right'),(361,'livingroom_window1'),(363,'office_window'),(400,'label');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-18 16:39:12
